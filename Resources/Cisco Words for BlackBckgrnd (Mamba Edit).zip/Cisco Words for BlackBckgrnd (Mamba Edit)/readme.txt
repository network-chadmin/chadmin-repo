Installing as using SecureCRT Syntax Highlighting

**** DISCLAIMER: I was not the original author of this syntax file.  I simply altered the colors and added a few words to it. ****


- Copy "Cisco Words for BlackBckgrnd(Mamba Edit).ini"

- Hit Windows button and type "Run"

- Type "%appdata%"

- Navigate to VanDyke --> Config --> Keywords

- If this folder doesn't exist yet, you'll have to create it

- Paste the .ini file here

#####################################################################

- Open up SecureCRT

- Nagivate to settings

- Under Terminal --> Emulation, make sure "Use color scheme" is checked

- Under Terminal --> Appearance, choose "Chalkboard" for the current color scheme.
This will ensure the right background color is used.

- Under Terminal --> Appearance, choose Consolas 18pt for font. This is all personal 
preferance, but I'm including my settings if you want to recreate it exactly.

- Under Terminal --> Keyword Highlighting, choose "Cisco Words for 
BlackBckgrnd(Mamba edit) for the lst name.

- Under Terminal --> Keyword Highlighting --> Advanced, have "color" checked, and "Reverse video" and "Bold" unchecked.  Whole words should be checked for match style.

- Close settings, and click "Options" on top and make sure "Keyword Highlighting" is
checked.  

- If you don't see results immediately, try closing whatever session you have open,
and restart it

- Enjoy!
